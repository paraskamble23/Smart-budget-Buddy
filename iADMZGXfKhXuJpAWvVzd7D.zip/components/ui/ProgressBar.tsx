import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { colors } from '@/constants/theme';

interface ProgressBarProps {
  current: number;
  target: number;
  color?: string;
  showPercentage?: boolean;
  height?: number;
}

export function ProgressBar({ 
  current, 
  target, 
  color = colors.primary, 
  showPercentage = true,
  height = 8 
}: ProgressBarProps) {
  const percentage = Math.min((current / target) * 100, 100);
  const isOverBudget = current > target;

  return (
    <View style={styles.container}>
      <View style={[styles.track, { height }]}>
        <View 
          style={[
            styles.progress, 
            { 
              width: `${Math.min(percentage, 100)}%`,
              backgroundColor: isOverBudget ? colors.error : color,
              height 
            }
          ]} 
        />
      </View>
      {showPercentage && (
        <Text 
          style={[
            styles.percentage,
            { color: isOverBudget ? colors.error : colors.onSurfaceVariant }
          ]}
        >
          {percentage.toFixed(0)}%
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  track: {
    flex: 1,
    backgroundColor: colors.surfaceVariant,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progress: {
    borderRadius: 4,
  },
  percentage: {
    fontSize: 12,
    fontWeight: '500',
    minWidth: 35,
    textAlign: 'right',
  },
});