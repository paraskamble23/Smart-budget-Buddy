import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { colors, typography } from '@/constants/theme';

interface AmountDisplayProps {
  amount: number;
  type?: 'income' | 'expense' | 'neutral';
  size?: 'small' | 'medium' | 'large';
  showSign?: boolean;
  style?: any;
}

export function AmountDisplay({ 
  amount, 
  type = 'neutral', 
  size = 'medium', 
  showSign = false,
  style 
}: AmountDisplayProps) {
  const formatAmount = (value: number) => {
    const sign = showSign ? (value >= 0 ? '+' : '') : '';
    return `${sign}$${Math.abs(value).toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const getColor = () => {
    switch (type) {
      case 'income':
        return colors.income;
      case 'expense':
        return colors.expense;
      default:
        return colors.onSurface;
    }
  };

  const getFontSize = () => {
    switch (size) {
      case 'small':
        return typography.caption.fontSize;
      case 'large':
        return typography.h2.fontSize;
      default:
        return typography.body.fontSize;
    }
  };

  return (
    <Text 
      style={[
        styles.amount,
        {
          color: getColor(),
          fontSize: getFontSize(),
          fontWeight: size === 'large' ? '700' : '600',
        },
        style,
      ]}
    >
      {formatAmount(amount)}
    </Text>
  );
}

const styles = StyleSheet.create({
  amount: {
    fontVariant: ['tabular-nums'],
  },
});