import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Card, Text } from 'react-native-paper';
import { colors, typography } from '@/constants/theme';

interface FinanceCardProps {
  title?: string;
  children: React.ReactNode;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
  onPress?: () => void;
}

export function FinanceCard({ title, children, style, contentStyle, onPress }: FinanceCardProps) {
  return (
    <Card 
      style={[styles.card, style]} 
      contentStyle={[styles.content, contentStyle]}
      onPress={onPress}
      mode="elevated"
    >
      {title && (
        <Text style={styles.title} variant="titleMedium">
          {title}
        </Text>
      )}
      {children}
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginVertical: 8,
    marginHorizontal: 16,
    backgroundColor: colors.surface,
    elevation: 2,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  content: {
    padding: 16,
  },
  title: {
    marginBottom: 12,
    color: colors.onSurface,
    fontWeight: '600',
  },
});