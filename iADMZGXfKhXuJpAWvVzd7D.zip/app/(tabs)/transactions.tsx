import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Platform, Modal, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Searchbar, FAB, Chip, Text as PaperText } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { AmountDisplay } from '@/components/ui/AmountDisplay';
import { colors, typography } from '@/constants/theme';
import { Transaction } from '@/types/finance';

export default function TransactionsScreen() {
  const { transactions } = useFinance();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  // Filter and search transactions
  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         transaction.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || transaction.type === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  // Group transactions by date
  const groupedTransactions = filteredTransactions.reduce((groups, transaction) => {
    const date = new Date(transaction.date).toDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {} as Record<string, Transaction[]>);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  const handleTransactionPress = (transaction: Transaction) => {
    showWebAlert(
      'Transaction Details',
      `${transaction.description}\nCategory: ${transaction.category}\nAmount: $${transaction.amount.toFixed(2)}\nDate: ${new Date(transaction.date).toLocaleDateString()}`
    );
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <PaperText style={styles.title}>Transactions</PaperText>
      </View>

      {/* Search and Filter */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder="Search transactions..."
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchbar}
        />
        
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.filterContainer}
          contentContainerStyle={styles.filterContent}
        >
          <Chip
            selected={selectedFilter === 'all'}
            onPress={() => setSelectedFilter('all')}
            style={styles.filterChip}
          >
            All
          </Chip>
          <Chip
            selected={selectedFilter === 'income'}
            onPress={() => setSelectedFilter('income')}
            style={styles.filterChip}
          >
            Income
          </Chip>
          <Chip
            selected={selectedFilter === 'expense'}
            onPress={() => setSelectedFilter('expense')}
            style={styles.filterChip}
          >
            Expenses
          </Chip>
        </ScrollView>
      </View>

      {/* Transactions List */}
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {Object.keys(groupedTransactions).length === 0 ? (
          <FinanceCard>
            <View style={styles.emptyState}>
              <MaterialIcons name="receipt-long" size={48} color={colors.onSurfaceVariant} />
              <PaperText style={styles.emptyText}>No transactions found</PaperText>
              <PaperText style={styles.emptySubtext}>
                {searchQuery ? 'Try adjusting your search' : 'Start by adding your first transaction'}
              </PaperText>
            </View>
          </FinanceCard>
        ) : (
          Object.entries(groupedTransactions)
            .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
            .map(([date, dayTransactions]) => (
              <FinanceCard key={date} title={formatDate(date)}>
                {dayTransactions.map((transaction, index) => (
                  <View key={transaction.id}>
                    <TouchableOpacity
                      style={styles.transactionItem}
                      onPress={() => handleTransactionPress(transaction)}
                    >
                      <View style={styles.transactionIcon}>
                        <MaterialIcons 
                          name={transaction.type === 'income' ? 'arrow-downward' : 'arrow-upward'} 
                          size={20} 
                          color={transaction.type === 'income' ? colors.income : colors.expense}
                        />
                      </View>
                      <View style={styles.transactionDetails}>
                        <PaperText style={styles.transactionDescription}>
                          {transaction.description}
                        </PaperText>
                        <PaperText style={styles.transactionCategory}>
                          {transaction.category}
                        </PaperText>
                      </View>
                      <View style={styles.transactionAmount}>
                        <AmountDisplay 
                          amount={transaction.amount} 
                          type={transaction.type}
                          size="medium"
                        />
                        <PaperText style={styles.transactionTime}>
                          {new Date(transaction.date).toLocaleTimeString('en-US', {
                            hour: 'numeric',
                            minute: '2-digit',
                          })}
                        </PaperText>
                      </View>
                    </TouchableOpacity>
                    {index < dayTransactions.length - 1 && <View style={styles.separator} />}
                  </View>
                ))}
              </FinanceCard>
            ))
        )}
        
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Floating Action Button */}
      <FAB
        icon="add"
        style={styles.fab}
        onPress={() => router.push('/add-transaction')}
        label="Add Transaction"
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  title: {
    ...typography.h2,
    color: colors.surface,
  },
  searchContainer: {
    backgroundColor: colors.surface,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.outline,
  },
  searchbar: {
    marginBottom: 8,
    elevation: 0,
    backgroundColor: colors.surfaceVariant,
  },
  filterContainer: {
    flexGrow: 0,
  },
  filterContent: {
    paddingVertical: 4,
    gap: 8,
  },
  filterChip: {
    marginRight: 8,
  },
  scrollView: {
    flex: 1,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    ...typography.h3,
    color: colors.onSurfaceVariant,
    marginTop: 16,
  },
  emptySubtext: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    textAlign: 'center',
    marginTop: 8,
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 12,
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionDetails: {
    flex: 1,
  },
  transactionDescription: {
    ...typography.body,
    color: colors.onSurface,
    fontWeight: '500',
  },
  transactionCategory: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  transactionAmount: {
    alignItems: 'flex-end',
  },
  transactionTime: {
    ...typography.small,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  separator: {
    height: 1,
    backgroundColor: colors.outline,
    marginLeft: 52,
  },
  bottomSpacing: {
    height: 100,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});