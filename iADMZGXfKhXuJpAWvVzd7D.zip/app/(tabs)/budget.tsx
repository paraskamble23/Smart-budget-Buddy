import React, { useState, Platform } from 'react';
import { View, ScrollView, StyleSheet, Modal, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FAB, Button, Text as PaperText } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { AmountDisplay } from '@/components/ui/AmountDisplay';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { colors, typography } from '@/constants/theme';

export default function BudgetScreen() {
  const { budgets, transactions } = useFinance();
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const currentMonth = new Date().toLocaleString('default', { month: 'long' });
  const totalBudget = budgets.reduce((sum, budget) => sum + budget.budgetAmount, 0);
  const totalSpent = budgets.reduce((sum, budget) => sum + budget.spentAmount, 0);
  const remainingBudget = totalBudget - totalSpent;

  const getBudgetStatus = (spent: number, budget: number) => {
    const percentage = (spent / budget) * 100;
    if (percentage >= 100) return 'Over budget';
    if (percentage >= 80) return 'Almost there';
    return 'On track';
  };

  const getBudgetColor = (spent: number, budget: number) => {
    const percentage = (spent / budget) * 100;
    if (percentage >= 100) return colors.error;
    if (percentage >= 80) return colors.warning;
    return colors.primary;
  };

  const handleSetBudget = () => {
    router.push('/set-budget');
  };

  const handleBudgetPress = (budgetId: string) => {
    const budget = budgets.find(b => b.id === budgetId);
    if (budget) {
      const categoryTransactions = transactions.filter(
        t => t.category === budget.category && t.type === 'expense'
      ).length;
      
      showWebAlert(
        budget.category,
        `Budget: $${budget.budgetAmount.toFixed(2)}\nSpent: $${budget.spentAmount.toFixed(2)}\nRemaining: $${(budget.budgetAmount - budget.spentAmount).toFixed(2)}\nTransactions: ${categoryTransactions}`
      );
    }
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <PaperText style={styles.title}>Budget Overview</PaperText>
        <PaperText style={styles.subtitle}>{currentMonth}</PaperText>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Budget Summary */}
        <FinanceCard title="Monthly Summary">
          <View style={styles.summaryGrid}>
            <View style={styles.summaryItem}>
              <PaperText style={styles.summaryLabel}>Total Budget</PaperText>
              <AmountDisplay amount={totalBudget} size="large" />
            </View>
            <View style={styles.summaryItem}>
              <PaperText style={styles.summaryLabel}>Total Spent</PaperText>
              <AmountDisplay amount={totalSpent} type="expense" size="large" />
            </View>
            <View style={styles.summaryItem}>
              <PaperText style={styles.summaryLabel}>Remaining</PaperText>
              <AmountDisplay 
                amount={remainingBudget} 
                type={remainingBudget >= 0 ? 'income' : 'expense'} 
                size="large" 
              />
            </View>
          </View>
          
          <View style={styles.overallProgress}>
            <PaperText style={styles.progressLabel}>Overall Progress</PaperText>
            <ProgressBar 
              current={totalSpent} 
              target={totalBudget}
              height={12}
            />
          </View>
        </FinanceCard>

        {/* Category Budgets */}
        <FinanceCard title="Category Budgets">
          {budgets.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialIcons name="pie-chart" size={48} color={colors.onSurfaceVariant} />
              <PaperText style={styles.emptyText}>No budgets set</PaperText>
              <PaperText style={styles.emptySubtext}>
                Start by setting budgets for your expense categories
              </PaperText>
              <Button 
                mode="contained" 
                onPress={handleSetBudget}
                style={styles.emptyButton}
              >
                Set Your First Budget
              </Button>
            </View>
          ) : (
            budgets.map((budget) => {
              const status = getBudgetStatus(budget.spentAmount, budget.budgetAmount);
              const color = getBudgetColor(budget.spentAmount, budget.budgetAmount);
              
              return (
                <TouchableOpacity
                  key={budget.id}
                  style={styles.budgetItem}
                  onPress={() => handleBudgetPress(budget.id)}
                >
                  <View style={styles.budgetHeader}>
                    <View style={styles.budgetTitleSection}>
                      <PaperText style={styles.budgetCategory}>
                        {budget.category}
                      </PaperText>
                      <PaperText style={[styles.budgetStatus, { color }]}>
                        {status}
                      </PaperText>
                    </View>
                    <View style={styles.budgetAmountSection}>
                      <AmountDisplay amount={budget.spentAmount} size="medium" />
                      <PaperText style={styles.budgetTotal}>
                        of <AmountDisplay amount={budget.budgetAmount} size="small" />
                      </PaperText>
                    </View>
                  </View>
                  
                  <ProgressBar 
                    current={budget.spentAmount} 
                    target={budget.budgetAmount}
                    color={color}
                  />
                  
                  <View style={styles.budgetFooter}>
                    <PaperText style={styles.remainingText}>
                      Remaining: <AmountDisplay 
                        amount={budget.budgetAmount - budget.spentAmount} 
                        type={budget.budgetAmount - budget.spentAmount >= 0 ? 'income' : 'expense'}
                        size="small"
                      />
                    </PaperText>
                  </View>
                </TouchableOpacity>
              );
            })
          )}
        </FinanceCard>

        {/* Budget Tips */}
        <FinanceCard title="Budget Tips">
          <View style={styles.tipItem}>
            <MaterialIcons name="lightbulb" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Set realistic budgets based on your spending history
            </PaperText>
          </View>
          <View style={styles.tipItem}>
            <MaterialIcons name="notifications" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Review and adjust your budgets monthly
            </PaperText>
          </View>
          <View style={styles.tipItem}>
            <MaterialIcons name="trending-down" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Use the 50/30/20 rule: 50% needs, 30% wants, 20% savings
            </PaperText>
          </View>
        </FinanceCard>

        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Floating Action Button */}
      <FAB
        icon="edit"
        style={styles.fab}
        onPress={handleSetBudget}
        label="Set Budget"
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  title: {
    ...typography.h2,
    color: colors.surface,
  },
  subtitle: {
    ...typography.caption,
    color: colors.surface,
    opacity: 0.9,
  },
  scrollView: {
    flex: 1,
  },
  summaryGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryLabel: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginBottom: 4,
    textAlign: 'center',
  },
  overallProgress: {
    gap: 8,
  },
  progressLabel: {
    ...typography.body,
    fontWeight: '500',
    color: colors.onSurface,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    ...typography.h3,
    color: colors.onSurfaceVariant,
    marginTop: 16,
  },
  emptySubtext: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  emptyButton: {
    marginTop: 8,
  },
  budgetItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.outline,
  },
  budgetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  budgetTitleSection: {
    flex: 1,
  },
  budgetCategory: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
  },
  budgetStatus: {
    ...typography.caption,
    fontWeight: '500',
    marginTop: 2,
  },
  budgetAmountSection: {
    alignItems: 'flex-end',
  },
  budgetTotal: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  budgetFooter: {
    marginTop: 8,
    alignItems: 'flex-end',
  },
  remainingText: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    gap: 12,
  },
  tipText: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    flex: 1,
    lineHeight: 18,
  },
  bottomSpacing: {
    height: 100,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});