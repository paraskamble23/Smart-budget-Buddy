import React, { useState, Platform } from 'react';
import { View, ScrollView, StyleSheet, Modal, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { FAB, Button, Text as PaperText } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { AmountDisplay } from '@/components/ui/AmountDisplay';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { colors, typography } from '@/constants/theme';

export default function GoalsScreen() {
  const { goals } = useFinance();
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const getGoalIcon = (category: string) => {
    switch (category) {
      case 'emergency': return 'security';
      case 'vacation': return 'flight';
      case 'purchase': return 'shopping-cart';
      case 'investment': return 'trending-up';
      default: return 'flag';
    }
  };

  const getProgressColor = (current: number, target: number) => {
    const percentage = (current / target) * 100;
    if (percentage >= 100) return colors.success;
    if (percentage >= 75) return colors.secondary;
    return colors.primary;
  };

  const getDaysRemaining = (targetDate: string) => {
    const target = new Date(targetDate);
    const today = new Date();
    const diffTime = target.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleGoalPress = (goalId: string) => {
    router.push(`/goal-detail?id=${goalId}`);
  };

  const handleCreateGoal = () => {
    showWebAlert('Create Goal', 'Goal creation feature coming soon!');
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <PaperText style={styles.title}>Savings Goals</PaperText>
        <PaperText style={styles.subtitle}>Track your financial targets</PaperText>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Goals Overview */}
        {goals.length > 0 && (
          <FinanceCard title="Progress Overview">
            <View style={styles.overviewStats}>
              <View style={styles.statItem}>
                <PaperText style={styles.statLabel}>Active Goals</PaperText>
                <PaperText style={styles.statValue}>{goals.length}</PaperText>
              </View>
              <View style={styles.statItem}>
                <PaperText style={styles.statLabel}>Total Target</PaperText>
                <AmountDisplay 
                  amount={goals.reduce((sum, goal) => sum + goal.targetAmount, 0)} 
                  size="medium"
                />
              </View>
              <View style={styles.statItem}>
                <PaperText style={styles.statLabel}>Total Saved</PaperText>
                <AmountDisplay 
                  amount={goals.reduce((sum, goal) => sum + goal.currentAmount, 0)} 
                  type="income"
                  size="medium"
                />
              </View>
            </View>
          </FinanceCard>
        )}

        {/* Individual Goals */}
        {goals.length === 0 ? (
          <FinanceCard>
            <View style={styles.emptyState}>
              <MaterialIcons name="flag" size={48} color={colors.onSurfaceVariant} />
              <PaperText style={styles.emptyText}>No savings goals yet</PaperText>
              <PaperText style={styles.emptySubtext}>
                Set your first savings goal to start building your financial future
              </PaperText>
              <Button 
                mode="contained" 
                onPress={handleCreateGoal}
                style={styles.emptyButton}
              >
                Create Your First Goal
              </Button>
            </View>
          </FinanceCard>
        ) : (
          goals.map((goal) => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            const daysRemaining = getDaysRemaining(goal.targetDate);
            const progressColor = getProgressColor(goal.currentAmount, goal.targetAmount);
            
            return (
              <FinanceCard key={goal.id}>
                <TouchableOpacity
                  style={styles.goalItem}
                  onPress={() => handleGoalPress(goal.id)}
                >
                  <View style={styles.goalHeader}>
                    <View style={styles.goalIconContainer}>
                      <MaterialIcons 
                        name={getGoalIcon(goal.category)} 
                        size={24} 
                        color={progressColor}
                      />
                    </View>
                    <View style={styles.goalInfo}>
                      <PaperText style={styles.goalTitle}>{goal.title}</PaperText>
                      <PaperText style={styles.goalDescription} numberOfLines={2}>
                        {goal.description}
                      </PaperText>
                    </View>
                    <MaterialIcons 
                      name="chevron-right" 
                      size={20} 
                      color={colors.onSurfaceVariant} 
                    />
                  </View>

                  <View style={styles.goalProgress}>
                    <View style={styles.progressHeader}>
                      <PaperText style={styles.progressText}>
                        <AmountDisplay amount={goal.currentAmount} size="small" /> of{' '}
                        <AmountDisplay amount={goal.targetAmount} size="small" />
                      </PaperText>
                      <PaperText style={styles.progressPercentage}>
                        {progress.toFixed(0)}%
                      </PaperText>
                    </View>
                    <ProgressBar 
                      current={goal.currentAmount} 
                      target={goal.targetAmount}
                      color={progressColor}
                      showPercentage={false}
                    />
                  </View>

                  <View style={styles.goalFooter}>
                    <View style={styles.goalMeta}>
                      <MaterialIcons name="schedule" size={16} color={colors.onSurfaceVariant} />
                      <PaperText style={styles.daysRemaining}>
                        {daysRemaining > 0 
                          ? `${daysRemaining} days remaining`
                          : daysRemaining === 0 
                            ? 'Target date is today'
                            : 'Target date passed'
                        }
                      </PaperText>
                    </View>
                    <PaperText style={styles.remainingAmount}>
                      <AmountDisplay 
                        amount={goal.targetAmount - goal.currentAmount} 
                        size="small"
                      /> remaining
                    </PaperText>
                  </View>
                </TouchableOpacity>
              </FinanceCard>
            );
          })
        )}

        {/* Goal Tips */}
        <FinanceCard title="Goal Setting Tips">
          <View style={styles.tipItem}>
            <MaterialIcons name="track-changes" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Make your goals specific, measurable, and time-bound
            </PaperText>
          </View>
          <View style={styles.tipItem}>
            <MaterialIcons name="auto-awesome" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Set up automatic transfers to save consistently
            </PaperText>
          </View>
          <View style={styles.tipItem}>
            <MaterialIcons name="celebration" size={20} color={colors.accent} />
            <PaperText style={styles.tipText}>
              Celebrate milestones to stay motivated
            </PaperText>
          </View>
        </FinanceCard>

        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Floating Action Button */}
      <FAB
        icon="add"
        style={styles.fab}
        onPress={handleCreateGoal}
        label="New Goal"
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  title: {
    ...typography.h2,
    color: colors.surface,
  },
  subtitle: {
    ...typography.caption,
    color: colors.surface,
    opacity: 0.9,
  },
  scrollView: {
    flex: 1,
  },
  overviewStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statLabel: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginBottom: 4,
    textAlign: 'center',
  },
  statValue: {
    ...typography.h3,
    color: colors.onSurface,
    fontWeight: '700',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    ...typography.h3,
    color: colors.onSurfaceVariant,
    marginTop: 16,
  },
  emptySubtext: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  emptyButton: {
    marginTop: 8,
  },
  goalItem: {
    gap: 16,
  },
  goalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  goalIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalInfo: {
    flex: 1,
  },
  goalTitle: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
  },
  goalDescription: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginTop: 2,
    lineHeight: 18,
  },
  goalProgress: {
    gap: 8,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  progressText: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  progressPercentage: {
    ...typography.caption,
    fontWeight: '600',
    color: colors.onSurface,
  },
  goalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  goalMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  daysRemaining: {
    ...typography.small,
    color: colors.onSurfaceVariant,
  },
  remainingAmount: {
    ...typography.small,
    color: colors.onSurfaceVariant,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    gap: 12,
  },
  tipText: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    flex: 1,
    lineHeight: 18,
  },
  bottomSpacing: {
    height: 100,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});