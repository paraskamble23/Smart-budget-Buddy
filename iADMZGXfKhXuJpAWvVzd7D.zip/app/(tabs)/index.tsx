import React, { useState, Platform } from 'react';
import { View, ScrollView, StyleSheet, Alert, Modal, Text, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, FAB, IconButton } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { AmountDisplay } from '@/components/ui/AmountDisplay';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { colors, typography } from '@/constants/theme';

export default function HomeScreen() {
  const { transactions, budgets, goals, insights, monthlyReport, loading } = useFinance();
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const recentTransactions = transactions.slice(0, 3);
  const topBudgets = budgets.slice(0, 2);
  const topGoal = goals[0];

  const handleQuickAdd = () => {
    router.push('/add-transaction');
  };

  const handleViewInsights = () => {
    router.push('/(tabs)/insights');
  };

  if (loading) {
    return (
      <SafeAreaView edges={['top']} style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading your financial data...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning! 👋</Text>
            <Text style={styles.subtitle}>Here is your financial overview</Text>
          </View>
          <IconButton
            icon="notifications-outline"
            size={24}
            iconColor={colors.onSurface}
            onPress={() => showWebAlert('Notifications', 'No new notifications')}
          />
        </View>

        {/* Monthly Overview */}
        {monthlyReport && (
          <FinanceCard title="This Month">
            <View style={styles.monthlyOverview}>
              <View style={styles.overviewItem}>
                <Text style={styles.overviewLabel}>Income</Text>
                <AmountDisplay 
                  amount={monthlyReport.totalIncome} 
                  type="income" 
                  size="medium"
                />
              </View>
              <View style={styles.overviewItem}>
                <Text style={styles.overviewLabel}>Expenses</Text>
                <AmountDisplay 
                  amount={monthlyReport.totalExpenses} 
                  type="expense" 
                  size="medium"
                />
              </View>
              <View style={styles.overviewItem}>
                <Text style={styles.overviewLabel}>Net Income</Text>
                <AmountDisplay 
                  amount={monthlyReport.netIncome} 
                  type={monthlyReport.netIncome >= 0 ? 'income' : 'expense'}
                  size="large"
                />
              </View>
            </View>
          </FinanceCard>
        )}

        {/* AI Insights Preview */}
        {insights.length > 0 && (
          <FinanceCard 
            title="AI Insights" 
            onPress={handleViewInsights}
          >
            <View style={styles.insightPreview}>
              <MaterialIcons name="psychology" size={24} color={colors.primary} />
              <View style={styles.insightContent}>
                <Text style={styles.insightTitle}>{insights[0].title}</Text>
                <Text style={styles.insightMessage} numberOfLines={2}>
                  {insights[0].message}
                </Text>
              </View>
              <MaterialIcons name="chevron-right" size={20} color={colors.onSurfaceVariant} />
            </View>
          </FinanceCard>
        )}

        {/* Quick Budget Status */}
        {topBudgets.length > 0 && (
          <FinanceCard title="Budget Status">
            {topBudgets.map((budget) => (
              <View key={budget.id} style={styles.budgetItem}>
                <View style={styles.budgetHeader}>
                  <Text style={styles.budgetCategory}>{budget.category}</Text>
                  <Text style={styles.budgetAmount}>
                    <AmountDisplay amount={budget.spentAmount} size="small" /> / 
                    <AmountDisplay amount={budget.budgetAmount} size="small" />
                  </Text>
                </View>
                <ProgressBar 
                  current={budget.spentAmount} 
                  target={budget.budgetAmount}
                  color={colors.primary}
                />
              </View>
            ))}
            <Button 
              mode="text" 
              onPress={() => router.push('/(tabs)/budget')}
              style={styles.viewAllButton}
            >
              View All Budgets
            </Button>
          </FinanceCard>
        )}

        {/* Top Goal Progress */}
        {topGoal && (
          <FinanceCard title="Savings Goal">
            <View style={styles.goalItem}>
              <View style={styles.goalHeader}>
                <Text style={styles.goalTitle}>{topGoal.title}</Text>
                <Text style={styles.goalAmount}>
                  <AmountDisplay amount={topGoal.currentAmount} size="small" /> / 
                  <AmountDisplay amount={topGoal.targetAmount} size="small" />
                </Text>
              </View>
              <ProgressBar 
                current={topGoal.currentAmount} 
                target={topGoal.targetAmount}
                color={colors.secondary}
              />
              <Text style={styles.goalDescription}>{topGoal.description}</Text>
            </View>
            <Button 
              mode="text" 
              onPress={() => router.push('/(tabs)/goals')}
              style={styles.viewAllButton}
            >
              View All Goals
            </Button>
          </FinanceCard>
        )}

        {/* Recent Transactions */}
        <FinanceCard title="Recent Transactions">
          {recentTransactions.map((transaction) => (
            <View key={transaction.id} style={styles.transactionItem}>
              <View style={styles.transactionIcon}>
                <MaterialIcons 
                  name={transaction.type === 'income' ? 'arrow-downward' : 'arrow-upward'} 
                  size={20} 
                  color={transaction.type === 'income' ? colors.income : colors.expense}
                />
              </View>
              <View style={styles.transactionDetails}>
                <Text style={styles.transactionDescription}>
                  {transaction.description}
                </Text>
                <Text style={styles.transactionCategory}>
                  {transaction.category}
                </Text>
              </View>
              <AmountDisplay 
                amount={transaction.amount} 
                type={transaction.type}
                size="medium"
              />
            </View>
          ))}
          <Button 
            mode="text" 
            onPress={() => router.push('/(tabs)/transactions')}
            style={styles.viewAllButton}
          >
            View All Transactions
          </Button>
        </FinanceCard>

        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Floating Action Button */}
      <FAB
        icon="add"
        style={styles.fab}
        onPress={handleQuickAdd}
        label="Add Transaction"
      />

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    ...typography.body,
    color: colors.onSurfaceVariant,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: colors.primary,
  },
  greeting: {
    ...typography.h2,
    color: colors.surface,
  },
  subtitle: {
    ...typography.caption,
    color: colors.surface,
    opacity: 0.9,
  },
  monthlyOverview: {
    gap: 16,
  },
  overviewItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  overviewLabel: {
    ...typography.body,
    color: colors.onSurfaceVariant,
  },
  insightPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  insightContent: {
    flex: 1,
  },
  insightTitle: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
  },
  insightMessage: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  budgetItem: {
    marginBottom: 16,
  },
  budgetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  budgetCategory: {
    ...typography.body,
    fontWeight: '500',
    color: colors.onSurface,
  },
  budgetAmount: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  goalItem: {
    gap: 8,
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  goalTitle: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
  },
  goalAmount: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  goalDescription: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    gap: 12,
  },
  transactionIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionDetails: {
    flex: 1,
  },
  transactionDescription: {
    ...typography.body,
    color: colors.onSurface,
  },
  transactionCategory: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
  },
  viewAllButton: {
    marginTop: 8,
  },
  bottomSpacing: {
    height: 100,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: colors.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});