import React, { useState, Platform } from 'react';
import { View, ScrollView, StyleSheet, Modal, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip, Button, Text as PaperText } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { AmountDisplay } from '@/components/ui/AmountDisplay';
import { colors, typography } from '@/constants/theme';
import { AIInsight } from '@/types/finance';

export default function InsightsScreen() {
  const { insights, monthlyReport, transactions } = useFinance();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'tip' | 'warning' | 'achievement' | 'forecast'>('all');
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const filteredInsights = insights.filter(insight => 
    selectedFilter === 'all' || insight.type === selectedFilter
  );

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'tip': return 'lightbulb';
      case 'warning': return 'warning';
      case 'achievement': return 'star';
      case 'forecast': return 'trending-up';
      default: return 'info';
    }
  };

  const getInsightColor = (type: string) => {
    switch (type) {
      case 'tip': return colors.primary;
      case 'warning': return colors.warning;
      case 'achievement': return colors.success;
      case 'forecast': return colors.secondary;
      default: return colors.neutral;
    }
  };

  const getInsightBackgroundColor = (type: string) => {
    switch (type) {
      case 'tip': return colors.primaryLight;
      case 'warning': return colors.accentLight;
      case 'achievement': return colors.secondaryLight;
      case 'forecast': return colors.secondaryLight;
      default: return colors.surfaceVariant;
    }
  };

  const handleInsightPress = (insight: AIInsight) => {
    showWebAlert(insight.title, insight.message);
  };

  const handleRefreshInsights = () => {
    showWebAlert('AI Analysis', 'Refreshing your financial insights...');
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <View style={styles.header}>
        <View>
          <PaperText style={styles.title}>AI Insights</PaperText>
          <PaperText style={styles.subtitle}>Personalized financial analysis</PaperText>
        </View>
        <TouchableOpacity onPress={handleRefreshInsights}>
          <MaterialIcons name="refresh" size={24} color={colors.surface} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Quick Stats */}
        {monthlyReport && (
          <FinanceCard title="Smart Analysis">
            <View style={styles.analysisGrid}>
              <View style={styles.analysisItem}>
                <MaterialIcons name="psychology" size={20} color={colors.primary} />
                <PaperText style={styles.analysisLabel}>Spending Score</PaperText>
                <PaperText style={styles.analysisValue}>
                  {monthlyReport.budgetStatus === 'on-track' ? '85/100' : '72/100'}
                </PaperText>
              </View>
              <View style={styles.analysisItem}>
                <MaterialIcons name="trending-up" size={20} color={colors.secondary} />
                <PaperText style={styles.analysisLabel}>Trend</PaperText>
                <PaperText style={[styles.analysisValue, { color: colors.success }]}>
                  Improving
                </PaperText>
              </View>
              <View style={styles.analysisItem}>
                <MaterialIcons name="schedule" size={20} color={colors.accent} />
                <PaperText style={styles.analysisLabel}>Next Review</PaperText>
                <PaperText style={styles.analysisValue}>7 days</PaperText>
              </View>
            </View>
          </FinanceCard>
        )}

        {/* Filter Chips */}
        <View style={styles.filterContainer}>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterContent}
          >
            <Chip
              selected={selectedFilter === 'all'}
              onPress={() => setSelectedFilter('all')}
              style={styles.filterChip}
            >
              All ({insights.length})
            </Chip>
            <Chip
              selected={selectedFilter === 'tip'}
              onPress={() => setSelectedFilter('tip')}
              style={styles.filterChip}
            >
              Tips ({insights.filter(i => i.type === 'tip').length})
            </Chip>
            <Chip
              selected={selectedFilter === 'warning'}
              onPress={() => setSelectedFilter('warning')}
              style={styles.filterChip}
            >
              Alerts ({insights.filter(i => i.type === 'warning').length})
            </Chip>
            <Chip
              selected={selectedFilter === 'achievement'}
              onPress={() => setSelectedFilter('achievement')}
              style={styles.filterChip}
            >
              Wins ({insights.filter(i => i.type === 'achievement').length})
            </Chip>
            <Chip
              selected={selectedFilter === 'forecast'}
              onPress={() => setSelectedFilter('forecast')}
              style={styles.filterChip}
            >
              Forecasts ({insights.filter(i => i.type === 'forecast').length})
            </Chip>
          </ScrollView>
        </View>

        {/* Insights List */}
        {filteredInsights.length === 0 ? (
          <FinanceCard>
            <View style={styles.emptyState}>
              <MaterialIcons name="psychology" size={48} color={colors.onSurfaceVariant} />
              <PaperText style={styles.emptyText}>No insights available</PaperText>
              <PaperText style={styles.emptySubtext}>
                Check back soon for personalized financial insights
              </PaperText>
            </View>
          </FinanceCard>
        ) : (
          filteredInsights.map((insight) => (
            <TouchableOpacity
              key={insight.id}
              onPress={() => handleInsightPress(insight)}
            >
              <FinanceCard>
                <View style={styles.insightItem}>
                  <View style={[
                    styles.insightIconContainer,
                    { backgroundColor: getInsightBackgroundColor(insight.type) }
                  ]}>
                    <MaterialIcons 
                      name={getInsightIcon(insight.type)} 
                      size={24} 
                      color={getInsightColor(insight.type)}
                    />
                  </View>
                  
                  <View style={styles.insightContent}>
                    <View style={styles.insightHeader}>
                      <PaperText style={styles.insightTitle}>
                        {insight.title}
                      </PaperText>
                      <PaperText style={[
                        styles.insightType,
                        { color: getInsightColor(insight.type) }
                      ]}>
                        {insight.type.toUpperCase()}
                      </PaperText>
                    </View>
                    
                    <PaperText style={styles.insightMessage}>
                      {insight.message}
                    </PaperText>
                    
                    {insight.amount && (
                      <View style={styles.insightAmount}>
                        <MaterialIcons name="attach-money" size={16} color={colors.onSurfaceVariant} />
                        <AmountDisplay amount={insight.amount} size="small" />
                      </View>
                    )}
                    
                    {insight.category && (
                      <View style={styles.insightCategory}>
                        <MaterialIcons name="category" size={16} color={colors.onSurfaceVariant} />
                        <PaperText style={styles.categoryText}>{insight.category}</PaperText>
                      </View>
                    )}
                    
                    <PaperText style={styles.insightDate}>
                      {new Date(insight.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit'
                      })}
                    </PaperText>
                  </View>
                  
                  <MaterialIcons name="chevron-right" size={20} color={colors.onSurfaceVariant} />
                </View>
              </FinanceCard>
            </TouchableOpacity>
          ))
        )}

        {/* AI Features Info */}
        <FinanceCard title="How AI Helps You">
          <View style={styles.featureList}>
            <View style={styles.featureItem}>
              <MaterialIcons name="analytics" size={20} color={colors.primary} />
              <PaperText style={styles.featureText}>
                Analyzes your spending patterns automatically
              </PaperText>
            </View>
            <View style={styles.featureItem}>
              <MaterialIcons name="notifications-active" size={20} color={colors.warning} />
              <PaperText style={styles.featureText}>
                Alerts you before you overspend
              </PaperText>
            </View>
            <View style={styles.featureItem}>
              <MaterialIcons name="auto-awesome" size={20} color={colors.secondary} />
              <PaperText style={styles.featureText}>
                Provides personalized saving recommendations
              </PaperText>
            </View>
            <View style={styles.featureItem}>
              <MaterialIcons name="preview" size={20} color={colors.accent} />
              <PaperText style={styles.featureText}>
                Forecasts future expenses and savings
              </PaperText>
            </View>
          </View>
        </FinanceCard>

        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    ...typography.h2,
    color: colors.surface,
  },
  subtitle: {
    ...typography.caption,
    color: colors.surface,
    opacity: 0.9,
  },
  scrollView: {
    flex: 1,
  },
  analysisGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  analysisItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  analysisLabel: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    textAlign: 'center',
  },
  analysisValue: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
    textAlign: 'center',
  },
  filterContainer: {
    backgroundColor: colors.surface,
    paddingVertical: 8,
  },
  filterContent: {
    paddingHorizontal: 16,
    gap: 8,
  },
  filterChip: {
    marginRight: 8,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    ...typography.h3,
    color: colors.onSurfaceVariant,
    marginTop: 16,
  },
  emptySubtext: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    textAlign: 'center',
    marginTop: 8,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  insightIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  insightContent: {
    flex: 1,
    gap: 8,
  },
  insightHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  insightTitle: {
    ...typography.body,
    fontWeight: '600',
    color: colors.onSurface,
    flex: 1,
    marginRight: 8,
  },
  insightType: {
    ...typography.small,
    fontWeight: '600',
  },
  insightMessage: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    lineHeight: 20,
  },
  insightAmount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  insightCategory: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  categoryText: {
    ...typography.small,
    color: colors.onSurfaceVariant,
  },
  insightDate: {
    ...typography.small,
    color: colors.onSurfaceVariant,
  },
  featureList: {
    gap: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  featureText: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    flex: 1,
    lineHeight: 18,
  },
  bottomSpacing: {
    height: 32,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});