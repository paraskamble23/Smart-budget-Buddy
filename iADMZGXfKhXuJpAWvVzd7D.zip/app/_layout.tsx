import { Stack } from 'expo-router';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { theme } from '@/constants/theme';
import { FinanceProvider } from '@/contexts/FinanceContext';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <PaperProvider theme={theme}>
        <FinanceProvider>
          <StatusBar style="light" backgroundColor="#2E7CF6" />
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="onboarding" />
            <Stack.Screen name="add-transaction" />
            <Stack.Screen name="set-budget" />
            <Stack.Screen name="goal-detail" />
          </Stack>
        </FinanceProvider>
      </PaperProvider>
    </SafeAreaProvider>
  );
}