import React, { useState, Platform } from 'react';
import { View, ScrollView, StyleSheet, Modal, Text, TouchableOpacity, Alert, KeyboardAvoidingView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TextInput, Button, SegmentedButtons, Chip, Text as PaperText } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useFinance } from '@/hooks/useFinance';
import { FinanceCard } from '@/components/ui/FinanceCard';
import { colors, typography } from '@/constants/theme';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/types/finance';

export default function AddTransactionScreen() {
  const { addTransaction } = useFinance();
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [naturalInput, setNaturalInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const categories = type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;

  const parseNaturalLanguage = (input: string) => {
    // Simple NLP simulation - in a real app, this would use actual NLP services
    const text = input.toLowerCase();
    
    // Extract amount
    const amountMatch = text.match(/(\$?\d+(?:\.\d{2})?)/);
    if (amountMatch) {
      const extractedAmount = amountMatch[1].replace('$', '');
      setAmount(extractedAmount);
    }

    // Determine type and category based on keywords
    const expenseKeywords = {
      'groceries': ['grocery', 'groceries', 'food shopping', 'supermarket'],
      'food & dining': ['restaurant', 'dinner', 'lunch', 'coffee', 'pizza', 'meal'],
      'transportation': ['gas', 'fuel', 'uber', 'taxi', 'bus', 'train'],
      'entertainment': ['movie', 'cinema', 'concert', 'game', 'entertainment'],
      'shopping': ['bought', 'purchase', 'shopping', 'store', 'clothes'],
      'bills & utilities': ['bill', 'electric', 'water', 'internet', 'phone', 'rent'],
    };

    const incomeKeywords = {
      'salary': ['salary', 'paycheck', 'wage'],
      'freelance': ['freelance', 'contract', 'client'],
      'business': ['business', 'profit', 'revenue'],
    };

    // Check for expense keywords
    for (const [cat, keywords] of Object.entries(expenseKeywords)) {
      if (keywords.some(keyword => text.includes(keyword))) {
        setType('expense');
        setCategory(cat.split(' ').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' '));
        break;
      }
    }

    // Check for income keywords
    for (const [cat, keywords] of Object.entries(incomeKeywords)) {
      if (keywords.some(keyword => text.includes(keyword))) {
        setType('income');
        setCategory(cat.charAt(0).toUpperCase() + cat.slice(1));
        break;
      }
    }

    // Set description (remove amount and common words)
    let desc = input.replace(/(\$?\d+(?:\.\d{2})?)/g, '').trim();
    desc = desc.replace(/^(i\s+)?(spent|paid|bought|earned|received)\s+/i, '').trim();
    desc = desc.replace(/\s+(on|for|at|from)\s+/g, ' ').trim();
    if (desc) {
      setDescription(desc.charAt(0).toUpperCase() + desc.slice(1));
    }
  };

  const handleNaturalInputSubmit = () => {
    if (!naturalInput.trim()) return;
    
    parseNaturalLanguage(naturalInput);
    showWebAlert('AI Processing', 'Transaction details extracted! Please review and adjust if needed.');
  };

  const handleSubmit = async () => {
    if (!amount || !description || !category) {
      showWebAlert('Missing Information', 'Please fill in all required fields.');
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      showWebAlert('Invalid Amount', 'Please enter a valid amount.');
      return;
    }

    setLoading(true);
    try {
      addTransaction({
        type,
        amount: numAmount,
        category,
        description,
        date: new Date().toISOString(),
      });

      showWebAlert(
        'Transaction Added',
        `Successfully added ${type} of $${numAmount.toFixed(2)}`,
        () => router.back()
      );
    } catch (error) {
      showWebAlert('Error', 'Failed to add transaction. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setAmount('');
    setDescription('');
    setCategory('');
    setNaturalInput('');
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <KeyboardAvoidingView 
        style={styles.flex} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <MaterialIcons name="arrow-back" size={24} color={colors.surface} />
          </TouchableOpacity>
          <PaperText style={styles.title}>Add Transaction</PaperText>
          <TouchableOpacity onPress={resetForm}>
            <MaterialIcons name="refresh" size={24} color={colors.surface} />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Natural Language Input */}
          <FinanceCard title="✨ Smart Input">
            <PaperText style={styles.nlpDescription}>
              Try typing naturally: "I spent $25 on groceries" or "Earned $500 from freelance work"
            </PaperText>
            <TextInput
              mode="outlined"
              placeholder="Describe your transaction naturally..."
              value={naturalInput}
              onChangeText={setNaturalInput}
              multiline
              numberOfLines={3}
              style={styles.naturalInput}
            />
            <Button 
              mode="contained" 
              onPress={handleNaturalInputSubmit}
              disabled={!naturalInput.trim()}
              style={styles.nlpButton}
            >
              Extract Details with AI
            </Button>
          </FinanceCard>

          {/* Manual Input Form */}
          <FinanceCard title="Transaction Details">
            {/* Type Selection */}
            <View style={styles.inputGroup}>
              <PaperText style={styles.label}>Type</PaperText>
              <SegmentedButtons
                value={type}
                onValueChange={(value) => {
                  setType(value as 'income' | 'expense');
                  setCategory(''); // Reset category when type changes
                }}
                buttons={[
                  {
                    value: 'expense',
                    label: 'Expense',
                    icon: 'arrow-upward',
                  },
                  {
                    value: 'income',
                    label: 'Income',
                    icon: 'arrow-downward',
                  },
                ]}
              />
            </View>

            {/* Amount Input */}
            <View style={styles.inputGroup}>
              <PaperText style={styles.label}>Amount *</PaperText>
              <TextInput
                mode="outlined"
                placeholder="0.00"
                value={amount}
                onChangeText={setAmount}
                keyboardType="numeric"
                left={<TextInput.Affix text="$" />}
                style={styles.input}
              />
            </View>

            {/* Category Selection */}
            <View style={styles.inputGroup}>
              <PaperText style={styles.label}>Category *</PaperText>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                style={styles.categoryScroll}
              >
                <View style={styles.categoryContainer}>
                  {categories.map((cat) => (
                    <Chip
                      key={cat}
                      selected={category === cat}
                      onPress={() => setCategory(cat)}
                      style={styles.categoryChip}
                    >
                      {cat}
                    </Chip>
                  ))}
                </View>
              </ScrollView>
            </View>

            {/* Description Input */}
            <View style={styles.inputGroup}>
              <PaperText style={styles.label}>Description *</PaperText>
              <TextInput
                mode="outlined"
                placeholder="Enter transaction description"
                value={description}
                onChangeText={setDescription}
                style={styles.input}
              />
            </View>
          </FinanceCard>

          {/* Quick Actions */}
          <FinanceCard title="Quick Add">
            <View style={styles.quickActions}>
              <TouchableOpacity 
                style={styles.quickAction}
                onPress={() => {
                  setType('expense');
                  setCategory('Groceries');
                  setDescription('Grocery shopping');
                }}
              >
                <MaterialIcons name="shopping-cart" size={24} color={colors.primary} />
                <PaperText style={styles.quickActionText}>Groceries</PaperText>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.quickAction}
                onPress={() => {
                  setType('expense');
                  setCategory('Food & Dining');
                  setDescription('Restaurant meal');
                }}
              >
                <MaterialIcons name="restaurant" size={24} color={colors.primary} />
                <PaperText style={styles.quickActionText}>Dining</PaperText>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.quickAction}
                onPress={() => {
                  setType('expense');
                  setCategory('Transportation');
                  setDescription('Transportation expense');
                }}
              >
                <MaterialIcons name="directions-car" size={24} color={colors.primary} />
                <PaperText style={styles.quickActionText}>Transport</PaperText>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.quickAction}
                onPress={() => {
                  setType('income');
                  setCategory('Salary');
                  setDescription('Monthly salary');
                }}
              >
                <MaterialIcons name="account-balance-wallet" size={24} color={colors.success} />
                <PaperText style={styles.quickActionText}>Salary</PaperText>
              </TouchableOpacity>
            </View>
          </FinanceCard>

          <View style={styles.bottomSpacing} />
        </ScrollView>

        {/* Submit Button */}
        <View style={styles.buttonContainer}>
          <Button
            mode="contained"
            onPress={handleSubmit}
            loading={loading}
            disabled={!amount || !description || !category}
            style={styles.submitButton}
            contentStyle={styles.submitButtonContent}
          >
            Add Transaction
          </Button>
        </View>
      </KeyboardAvoidingView>

      {/* Web Alert Modal */}
      {Platform.OS === 'web' && (
        <Modal visible={alertConfig.visible} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <View style={styles.alertBox}>
              <Text style={styles.alertTitle}>{alertConfig.title}</Text>
              <Text style={styles.alertMessage}>{alertConfig.message}</Text>
              <TouchableOpacity 
                style={styles.alertButton}
                onPress={() => {
                  alertConfig.onOk?.();
                  setAlertConfig(prev => ({ ...prev, visible: false }));
                }}
              >
                <Text style={styles.alertButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: {
    flex: 1,
  },
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    ...typography.h2,
    color: colors.surface,
  },
  scrollView: {
    flex: 1,
  },
  nlpDescription: {
    ...typography.caption,
    color: colors.onSurfaceVariant,
    marginBottom: 12,
    lineHeight: 18,
  },
  naturalInput: {
    marginBottom: 12,
  },
  nlpButton: {
    marginTop: 4,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    ...typography.body,
    fontWeight: '500',
    color: colors.onSurface,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.surface,
  },
  categoryScroll: {
    flexGrow: 0,
  },
  categoryContainer: {
    flexDirection: 'row',
    gap: 8,
    paddingRight: 16,
  },
  categoryChip: {
    marginRight: 0,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  quickAction: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.surfaceVariant,
    borderRadius: 12,
  },
  quickActionText: {
    ...typography.caption,
    color: colors.onSurface,
    marginTop: 8,
    textAlign: 'center',
  },
  bottomSpacing: {
    height: 20,
  },
  buttonContainer: {
    padding: 16,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.outline,
  },
  submitButton: {
    paddingVertical: 4,
  },
  submitButtonContent: {
    paddingVertical: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
    maxWidth: '90%',
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});