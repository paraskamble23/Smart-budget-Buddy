import React, { createContext, ReactNode, useState, useEffect } from 'react';
import { Transaction, Budget, Goal, AIInsight, MonthlyReport } from '@/types/finance';
import { generateMockData, generateAIInsights } from '@/services/mockData';

interface FinanceContextType {
  transactions: Transaction[];
  budgets: Budget[];
  goals: Goal[];
  insights: AIInsight[];
  monthlyReport: MonthlyReport | null;
  loading: boolean;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateBudget: (budget: Budget) => void;
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  updateGoal: (goalId: string, amount: number) => void;
  refreshData: () => void;
}

export const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export function FinanceProvider({ children }: { children: ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [monthlyReport, setMonthlyReport] = useState<MonthlyReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const mockData = generateMockData();
      setTransactions(mockData.transactions);
      setBudgets(mockData.budgets);
      setGoals(mockData.goals);
      setMonthlyReport(mockData.monthlyReport);
      
      // Generate AI insights based on data
      const aiInsights = generateAIInsights(mockData.transactions, mockData.budgets);
      setInsights(aiInsights);
    } catch (error) {
      console.error('Error loading initial data:', error);
    } finally {
      setLoading(false);
    }
  };

  const addTransaction = (transactionData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setTransactions(prev => [newTransaction, ...prev]);
    
    // Update budget spent amount if it's an expense
    if (newTransaction.type === 'expense') {
      setBudgets(prev => prev.map(budget => 
        budget.category === newTransaction.category
          ? { ...budget, spentAmount: budget.spentAmount + newTransaction.amount }
          : budget
      ));
    }
  };

  const updateBudget = (updatedBudget: Budget) => {
    setBudgets(prev => prev.map(budget =>
      budget.id === updatedBudget.id ? updatedBudget : budget
    ));
  };

  const addGoal = (goalData: Omit<Goal, 'id' | 'createdAt'>) => {
    const newGoal: Goal = {
      ...goalData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setGoals(prev => [newGoal, ...prev]);
  };

  const updateGoal = (goalId: string, amount: number) => {
    setGoals(prev => prev.map(goal =>
      goal.id === goalId
        ? { ...goal, currentAmount: Math.min(goal.currentAmount + amount, goal.targetAmount) }
        : goal
    ));
  };

  const refreshData = () => {
    loadInitialData();
  };

  const value: FinanceContextType = {
    transactions,
    budgets,
    goals,
    insights,
    monthlyReport,
    loading,
    addTransaction,
    updateBudget,
    addGoal,
    updateGoal,
    refreshData,
  };

  return (
    <FinanceContext.Provider value={value}>
      {children}
    </FinanceContext.Provider>
  );
}