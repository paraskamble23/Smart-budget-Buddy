import { Transaction, Budget, Goal, AIInsight, MonthlyReport, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/types/finance';

export function generateMockData() {
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Generate transactions for the last 30 days
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'income',
      amount: 4500,
      category: 'Salary',
      description: 'Monthly salary',
      date: new Date(currentYear, currentMonth, 1).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 1).toISOString(),
    },
    {
      id: '2',
      type: 'expense',
      amount: 85.50,
      category: 'Groceries',
      description: 'Weekly grocery shopping',
      date: new Date(currentYear, currentMonth, 3).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 3).toISOString(),
    },
    {
      id: '3',
      type: 'expense',
      amount: 1200,
      category: 'Bills & Utilities',
      description: 'Rent payment',
      date: new Date(currentYear, currentMonth, 5).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 5).toISOString(),
    },
    {
      id: '4',
      type: 'expense',
      amount: 45.00,
      category: 'Food & Dining',
      description: 'Dinner at restaurant',
      date: new Date(currentYear, currentMonth, 8).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 8).toISOString(),
    },
    {
      id: '5',
      type: 'expense',
      amount: 25.00,
      category: 'Transportation',
      description: 'Gas station',
      date: new Date(currentYear, currentMonth, 10).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 10).toISOString(),
    },
    {
      id: '6',
      type: 'income',
      amount: 500,
      category: 'Freelance',
      description: 'Web design project',
      date: new Date(currentYear, currentMonth, 12).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 12).toISOString(),
    },
    {
      id: '7',
      type: 'expense',
      amount: 120.00,
      category: 'Shopping',
      description: 'Clothing purchase',
      date: new Date(currentYear, currentMonth, 15).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 15).toISOString(),
    },
    {
      id: '8',
      type: 'expense',
      amount: 75.50,
      category: 'Entertainment',
      description: 'Movie tickets and snacks',
      date: new Date(currentYear, currentMonth, 18).toISOString(),
      createdAt: new Date(currentYear, currentMonth, 18).toISOString(),
    },
  ];

  // Generate budgets
  const budgets: Budget[] = [
    {
      id: '1',
      category: 'Food & Dining',
      budgetAmount: 300,
      spentAmount: 45,
      month: currentDate.toLocaleString('default', { month: 'long' }),
      year: currentYear,
    },
    {
      id: '2',
      category: 'Groceries',
      budgetAmount: 400,
      spentAmount: 85.50,
      month: currentDate.toLocaleString('default', { month: 'long' }),
      year: currentYear,
    },
    {
      id: '3',
      category: 'Entertainment',
      budgetAmount: 200,
      spentAmount: 75.50,
      month: currentDate.toLocaleString('default', { month: 'long' }),
      year: currentYear,
    },
    {
      id: '4',
      category: 'Transportation',
      budgetAmount: 150,
      spentAmount: 25,
      month: currentDate.toLocaleString('default', { month: 'long' }),
      year: currentYear,
    },
    {
      id: '5',
      category: 'Shopping',
      budgetAmount: 250,
      spentAmount: 120,
      month: currentDate.toLocaleString('default', { month: 'long' }),
      year: currentYear,
    },
  ];

  // Generate goals
  const goals: Goal[] = [
    {
      id: '1',
      title: 'Emergency Fund',
      description: 'Build emergency fund for 6 months expenses',
      targetAmount: 15000,
      currentAmount: 8500,
      targetDate: new Date(currentYear + 1, 5, 1).toISOString(),
      category: 'emergency',
      createdAt: new Date(currentYear, 0, 1).toISOString(),
    },
    {
      id: '2',
      title: 'Summer Vacation',
      description: 'Trip to Europe next summer',
      targetAmount: 3500,
      currentAmount: 1200,
      targetDate: new Date(currentYear + 1, 6, 15).toISOString(),
      category: 'vacation',
      createdAt: new Date(currentYear, 1, 15).toISOString(),
    },
    {
      id: '3',
      title: 'New Laptop',
      description: 'MacBook Pro for work',
      targetAmount: 2500,
      currentAmount: 900,
      targetDate: new Date(currentYear, 11, 1).toISOString(),
      category: 'purchase',
      createdAt: new Date(currentYear, 2, 10).toISOString(),
    },
  ];

  // Calculate monthly report
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const monthlyReport: MonthlyReport = {
    month: currentDate.toLocaleString('default', { month: 'long' }),
    year: currentYear,
    totalIncome,
    totalExpenses,
    netIncome: totalIncome - totalExpenses,
    topCategories: [
      { category: 'Bills & Utilities', amount: 1200, percentage: 78, trend: 'stable' },
      { category: 'Shopping', amount: 120, percentage: 8, trend: 'down' },
      { category: 'Groceries', amount: 85.50, percentage: 6, trend: 'up' },
      { category: 'Entertainment', amount: 75.50, percentage: 5, trend: 'stable' },
    ],
    budgetStatus: 'on-track',
  };

  return {
    transactions,
    budgets,
    goals,
    monthlyReport,
  };
}

export function generateAIInsights(transactions: Transaction[], budgets: Budget[]): AIInsight[] {
  const insights: AIInsight[] = [
    {
      id: '1',
      type: 'tip',
      title: 'Great Job on Groceries!',
      message: 'You have spent 79% less on groceries compared to last month. Keep up the smart shopping!',
      category: 'Groceries',
      date: new Date().toISOString(),
    },
    {
      id: '2',
      type: 'warning',
      title: 'Entertainment Budget Alert',
      message: 'You have used 38% of your entertainment budget this month. Consider planning your remaining entertainment expenses.',
      category: 'Entertainment',
      amount: 75.50,
      date: new Date().toISOString(),
    },
    {
      id: '3',
      type: 'achievement',
      title: 'Savings Milestone Reached!',
      message: 'Congratulations! You have saved 15% more than your target this month.',
      date: new Date().toISOString(),
    },
    {
      id: '4',
      type: 'forecast',
      title: 'Monthly Forecast',
      message: 'Based on your spending pattern, you are projected to save $1,250 this month.',
      date: new Date().toISOString(),
    },
    {
      id: '5',
      type: 'tip',
      title: 'Investment Opportunity',
      message: 'You have consistent savings. Consider investing $500 monthly in a diversified portfolio for long-term growth.',
      date: new Date().toISOString(),
    },
  ];

  return insights;
}