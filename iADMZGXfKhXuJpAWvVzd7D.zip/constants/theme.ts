import { MD3LightTheme } from 'react-native-paper';

export const colors = {
  primary: '#2E7CF6',
  primaryLight: '#E3F2FD',
  secondary: '#10B981',
  secondaryLight: '#ECFDF5',
  accent: '#F59E0B',
  accentLight: '#FEF3C7',
  error: '#EF4444',
  errorLight: '#FEF2F2',
  warning: '#F59E0B',
  success: '#10B981',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  surfaceVariant: '#F1F5F9',
  onSurface: '#1E293B',
  onSurfaceVariant: '#64748B',
  outline: '#CBD5E1',
  shadow: 'rgba(0, 0, 0, 0.1)',
  income: '#10B981',
  expense: '#EF4444',
  neutral: '#6B7280',
};

export const theme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: colors.primary,
    secondary: colors.secondary,
    tertiary: colors.accent,
    surface: colors.surface,
    surfaceVariant: colors.surfaceVariant,
    background: colors.background,
    error: colors.error,
    onSurface: colors.onSurface,
    onSurfaceVariant: colors.onSurfaceVariant,
    outline: colors.outline,
  },
};

export const typography = {
  h1: {
    fontSize: 32,
    fontWeight: '700' as const,
    lineHeight: 40,
  },
  h2: {
    fontSize: 24,
    fontWeight: '600' as const,
    lineHeight: 32,
  },
  h3: {
    fontSize: 20,
    fontWeight: '600' as const,
    lineHeight: 28,
  },
  body: {
    fontSize: 16,
    fontWeight: '400' as const,
    lineHeight: 24,
  },
  caption: {
    fontSize: 14,
    fontWeight: '400' as const,
    lineHeight: 20,
  },
  small: {
    fontSize: 12,
    fontWeight: '400' as const,
    lineHeight: 16,
  },
};